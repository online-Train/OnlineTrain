-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2021 at 11:21 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railway`
--

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `email` varchar(30) NOT NULL,
  `amount` int(5) NOT NULL,
  `nameoncard` int(30) NOT NULL,
  `cardNumber` int(12) NOT NULL,
  `expiration` int(4) NOT NULL,
  `ccv` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `resetpassword`
--

CREATE TABLE `resetpassword` (
  `email` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `newpassword` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resetpassword`
--

INSERT INTO `resetpassword` (`email`, `password`, `newpassword`) VALUES
('dulmaheshi101@gmail.', 'Maheshika1', 'Maheshika1');

-- --------------------------------------------------------

--
-- Table structure for table `signin`
--

CREATE TABLE `signin` (
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signin`
--

INSERT INTO `signin` (`username`, `password`) VALUES
('dulmaheshi101@gmail.', 'Dulani123#');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pin` int(4) NOT NULL,
  `nic_passport` varchar(12) NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(20) NOT NULL,
  `cinfirmPassword` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`firstname`, `lastname`, `email`, `pin`, `nic_passport`, `phone`, `password`, `cinfirmPassword`) VALUES
('Kasuni', 'Dananjana', 'kasu123765@gmail.com', 3452, '923456789', 776543210, 'kasuni1243', 'kasuni1243'),
('Subashini', 'Damayanthi', 'manikesu@gmail.com', 7654, '932345213', 712346583, '6543s65', '6543s65'),
('Madushi', 'Edirisingh', 'madushi234@gmail.com', 7639, '9234765438', 712437654, 'Mad6543#', 'Mad6543#'),
('Dulani', 'Maheshika', 'dulmaheshi101@gmail.com', 9000, '946810067V', 775770949, 'Dulani123#', 'Dulani123#');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
