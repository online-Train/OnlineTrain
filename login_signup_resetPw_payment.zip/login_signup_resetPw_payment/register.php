<?php

session_start();
if(isset($_SESSION['signup'])!="")
{
 header("Location: homepage.html");
}
include_once 'dbconnect.php';

// if(isset($_POST['btn-signup']))
// {
 $firstname=$_POST['firstname'];
 $lastname=$_POST['lastname'];
  $email=$_POST['email'];
   $NICorPassport=$_POST['NICorPassport'];
 $phone=$_POST['phone'];
 $Password=$_POST['Password'];
 $ConfirmPassword=$_POST['ConfirmPassword'];
 
 
 if(mysqli_query($conn,"INSERT INTO railway(firstname,lastname,email,NICorPassport,phone,Password,ConfirmPassword)VALUES('$firstname','$lastname','$email','$NICorPassport','$phone','$Password','$ConfirmPassword')"))
 {
  $_SESSION['signup']=$firstname;
        header("Location: homepage.html");
         }
 else
 {
  ?>
        <script>alert('Your registration successfull!!...');</script>
        <?php
 }
// }
mysqli_close($conn);
?>